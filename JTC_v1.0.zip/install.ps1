﻿pip install -r requirements.txt
Read-Host -Prompt "Press Enter to exit"
